fun main() {
    var listaPersonas: MutableList<Persona> = mutableListOf<Persona>()

    // Primer objeto con tus datos (Edad correcta)
    var miObjetoPersona: Persona = Persona("12345678", "Cristopher Suarez", 22, "8888-8888")
    listaPersonas.add(miObjetoPersona)

    // Segundo objeto (Aquí el instructor pone -21 para probar la validación)
    listaPersonas.add(Persona("111", "Cristian", -21, "123456"))

    for (p in listaPersonas) {
        p.imprimirDatos()
    }
}