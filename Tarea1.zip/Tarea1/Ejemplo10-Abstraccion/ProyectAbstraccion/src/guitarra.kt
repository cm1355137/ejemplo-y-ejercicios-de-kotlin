class Guitarra(nombre: String) : Instrumento(nombre, "Cuerda") {

    override fun tocar() {
        println("Se están rasgueando las cuerdas de la guitarra $nombre.")
    }
}