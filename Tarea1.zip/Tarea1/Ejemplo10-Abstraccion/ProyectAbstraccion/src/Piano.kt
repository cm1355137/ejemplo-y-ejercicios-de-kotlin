class Piano(nombre: String) : Instrumento(nombre, "Percusión/Teclado") {

    override fun tocar() {
        println("Se están presionando las teclas del piano $nombre.")
    }
}