fun main() {
    // No podés hacer: val ins = Instrumento("Genérico", "Viento") -> Daría ERROR

    val miGuitarra = Guitarra("Fender")
    val miPiano = Piano("Yamaha")

    val orquesta: MutableList<Instrumento> = mutableListOf(miGuitarra, miPiano)

    println("--- CONCIERTO EN MARCHA ---")
    for (instrumento in orquesta) {
        instrumento.mostrarInfo() // Método heredado
        instrumento.tocar()       // Método abstracto ejecutado por cada uno
        println("---------------------------")
    }
}