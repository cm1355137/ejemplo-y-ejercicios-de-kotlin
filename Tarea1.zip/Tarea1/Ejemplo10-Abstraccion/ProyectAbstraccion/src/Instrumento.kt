abstract class Instrumento(
    val nombre: String,
    val tipo: String
) {
    // Método normal
    fun mostrarInfo() {
        println("Instrumento: $nombre | Tipo: $tipo")
    }

    // MÉTODO ABSTRACTO (Sin cuerpo {})
    // Obliga a las hijas a decir CÓMO se tocan
    abstract fun tocar()
}