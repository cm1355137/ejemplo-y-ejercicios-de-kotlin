fun main() {
    println("EJEMPLO DE CONSTRUCTORES")
    var miObjetoPersona:Persona = Persona("12345678", "Cristopher Suarez", 22, "8888-8888")

    println("El nombre de la persona es ${miObjetoPersona.nombre}")

    miObjetoPersona.caminar()
    miObjetoPersona.imprimirDatos()
}