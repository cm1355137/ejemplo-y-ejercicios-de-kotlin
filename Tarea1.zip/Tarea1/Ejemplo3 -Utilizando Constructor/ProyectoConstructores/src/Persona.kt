class Persona(documento:String, nombre:String, edad:Int, telefono:String) {

    var documento:String = ""
    var nombre:String = ""
    var edad:Int = 0
    var telefono:String = ""

    init {
        this.documento = documento
        this.nombre = nombre
        this.edad = edad
        this.telefono = telefono
        println("La persona se ha creado")
    }

    fun caminar(){
        println("La persona está caminando...")
    }

    fun imprimirDatos(){
        var texto = "Nombre: $nombre \nDocumento: $documento \nEdad: $edad \nTelefono: $telefono"
        println(texto)
    }
}