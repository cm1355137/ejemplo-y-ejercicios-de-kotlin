open class Persona(
    private var documento: String,
    private var nombre: String,
    private var edad: Int,
    private var telefono: String
) {
    // Función para obtener la edad (Getter)
    fun getEdad(): Int {
        return edad
    }

    // Función para modificar la edad (Setter)
    fun setEdad(nuevaEdad: Int) {
        edad = nuevaEdad
    }

    open fun imprimirDatos() {
        println("Documento: $documento, Nombre: $nombre, Edad: $edad, Teléfono: $telefono")
    }
}