class Robot {
}