fun main() {
    
    val miEstudiante = Estudiante("12345678", "Cristopher Suarez", 26, "8888-8888", "2026-UNHSJ")

    // 1. Usando el Setter para cambiar la edad
    miEstudiante.setEdad(20)

    // 2. Usando el Getter para imprimir solo la edad
    println("La nueva edad es: ${miEstudiante.getEdad()}")

    // 3. Imprimir todo
    miEstudiante.imprimirDatos()
}