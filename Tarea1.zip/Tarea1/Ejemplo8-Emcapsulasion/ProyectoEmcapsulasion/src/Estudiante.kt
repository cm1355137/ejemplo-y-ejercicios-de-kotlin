class Estudiante(
    documento: String,
    nombre: String,
    edad: Int,
    telefono: String,
    private var carnet: String // El carnet también se queda privado
) : Persona(documento, nombre, edad, telefono) {

    override fun imprimirDatos() {
        super.imprimirDatos()
        println("Carnet: $carnet")
    }
}