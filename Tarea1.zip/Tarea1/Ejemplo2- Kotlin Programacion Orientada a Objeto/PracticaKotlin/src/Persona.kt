class Persona {
        // Atributos (Las variables del video)
        var documento: String = ""
        var nombre: String = ""
        var edad: Int = 0
        var telefono: String = ""

        // Método para simular una acción
        fun caminar() {
            println("$nombre está caminando...")
        }

        // Método para mostrar todos los datos juntos
        fun imprimirDatos(): String {
            val datos = "Documento: $documento\nNombre: $nombre\nEdad: $edad\nTeléfono: $telefono"
            return datos

    }
}