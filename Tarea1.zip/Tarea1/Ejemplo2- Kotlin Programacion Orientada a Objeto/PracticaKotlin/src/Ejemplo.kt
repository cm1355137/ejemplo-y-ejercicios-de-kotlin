class Ejemplo {
    fun iniciar(){

        println("EJEMPLO PROGRAMACION ORIENTADA A OBJETOS")
    }
}