//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
        // 1. Crear el objeto (Instanciar)
        val miPersona = Persona()

        // 2. Asignar datos (Como hace el tipo al final del video)
        miPersona.documento = "12345678"
        miPersona.nombre = "Cristopher Suarez" // Puse tu nombre para que sea original
        miPersona.edad = 22
        miPersona.telefono = "8888-8888"

        // 3. Ejecutar las funciones
        miPersona.caminar()

        println("--- Datos Completos ---")
        println(miPersona.imprimirDatos())
    }


