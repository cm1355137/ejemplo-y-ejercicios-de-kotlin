fun main() {
    // 1. Instancia de la clase normal (Guitarra)
    val miGuitarra = Guitarra("Yamaha")

    // 2. Creación de Clase Anónima (Flauta) como sale en tu captura
    val miFlauta = object : Instrumento("Flauta", "Viento") {
        override fun tocar() {
            println("Se está soplando la flauta $nombre")
        }
    }

    // 3. Creación de Clase Anónima (Batería)
    val miBateria = object : Instrumento("Batería", "Percusión") {
        override fun tocar() {
            println("Se están golpeando los tambores de la batería $nombre")
        }
    }

    // Ejecución
    miGuitarra.mostrarInfo()
    miGuitarra.tocar()

    println("---------------------------")

    miFlauta.mostrarInfo()
    miFlauta.tocar()

    println("---------------------------")

    miBateria.mostrarInfo()
    miBateria.tocar()
}