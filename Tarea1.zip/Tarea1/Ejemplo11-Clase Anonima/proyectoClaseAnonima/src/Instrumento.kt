abstract class Instrumento(
    val nombre: String,
    val tipo: String
) {
    fun mostrarInfo() {
        println("Instrumento: $nombre | Tipo: $tipo")
    }

    abstract fun tocar()
}