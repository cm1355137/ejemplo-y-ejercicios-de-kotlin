class Pajaro : Animal() {
    override fun comer(): String {
        return "El animal está comiendo"
    }
}