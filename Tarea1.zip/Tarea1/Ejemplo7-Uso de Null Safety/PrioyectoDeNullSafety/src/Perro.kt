class Perro : Animal() {
    override fun comer(): String {
        return "El animal está comiendo"
    }
}