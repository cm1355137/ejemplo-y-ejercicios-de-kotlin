open class Animal {
    open fun comer(): String {
        return "El animal está comiendo"
    }
}