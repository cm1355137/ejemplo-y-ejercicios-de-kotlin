fun main() {
    iniciar()
}

fun iniciar() {
    var miPerro: Perro? = null
    println(miPerro?.comer() ?: "El objeto Perro es Null")
}