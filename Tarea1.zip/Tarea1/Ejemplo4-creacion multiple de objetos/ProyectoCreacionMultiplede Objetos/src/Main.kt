fun main() {
    var listaPersonas: MutableList<Persona> = mutableListOf<Persona>()

    var miObjetoPersona: Persona = Persona("12345678", "Cristopher Suarez", 22, "8888-8888")
    listaPersonas.add(miObjetoPersona)

    listaPersonas.add(Persona("111", "Cristian", 21, "123456"))

    for (p in listaPersonas) {
        p.imprimirDatos()
    }
}