fun main() {
    var miEstudiante: Estudiante = Estudiante("12345678", "Cristopher Suarez", 26, "8888-8888", "2026-UNHSJ")
    miEstudiante.imprimirDatos()
    miEstudiante.estudiar()

    var miRobot: Robot = Robot("999", "Robot-X", 5, "0000")
    miRobot.imprimirDatos()
    miRobot.grabar()
}