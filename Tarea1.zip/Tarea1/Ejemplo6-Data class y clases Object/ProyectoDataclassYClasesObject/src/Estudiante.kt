class Estudiante(documento: String, nombre: String, edad: Int, telefono: String, var codigo: String) :
    Persona(documento, nombre, edad, telefono) {

    fun estudiar() {
        println("El estudiante $nombre está estudiando...")
    }
}