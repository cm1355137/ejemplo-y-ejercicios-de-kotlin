open class Persona(documento:String, nombre:String, edad:Int, telefono:String) {

    var documento:String = ""
    var nombre:String = ""
    var edad:Int = 0
    var telefono:String = ""

    constructor() : this("", "", 0, "") {
        println("Se ejecuto el constructor secundario")
    }

    init {
        this.documento = documento
        this.nombre = nombre

        if (edad < 0) {
            this.edad = 0
        } else {
            this.edad = edad
        }

        this.telefono = telefono
        println("La persona se ha creado")
    }

    fun caminar(){
        println("La persona está caminando...")
    }

    fun imprimirDatos(){
        var texto = "Nombre: $nombre \nDocumento: $documento \nEdad: $edad \nTelefono: $telefono"
        println(texto)
    }
}