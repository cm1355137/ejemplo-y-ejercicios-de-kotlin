class Robot(documento: String, nombre: String, edad: Int, telefono: String) :
    Persona(documento, nombre, edad, telefono) {

    fun grabar() {
        println("El robot $nombre está grabando...")
    }
}